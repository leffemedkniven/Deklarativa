
initSubseq :: Int -> Int -> [Int] -> [(Int, Int, [Int])]
initSubseq i j [x] = [(i,j,[x])]
initSubseq i j xs = [(i, j, xs)] ++ initSubseq i (j-1) (init xs)

tailSubseq :: Int -> Int -> [Int] -> [(Int, Int, [Int])]
tailSubseq i j [x] = [(i,j,[x])]
tailSubseq i j xs = ([(i, j, xs)] ++ tailSubseq (i+1) j (tail xs) ++ initSubseq i (j-1) (init xs))

summ :: [Int] -> Int
summ [] = 0
summ (x : xs) = x + summ xs

first :: (Int, Int, [Int]) -> Int
first (x,_,[]) = x
first (x,_,_) = x

second :: (Int, Int, [Int]) -> Int
second (_,x,[]) = x
second (_,x,_) = x

third :: (Int, Int, [Int]) -> [Int]
third (_,_,[]) = []
third(_,_,x) = x

sumSubseq :: [(Int, Int, [Int])] -> [(Int, Int, Int,[Int])]
sumSubseq [x] = [(summ (third x), (first x), (second x), third(x))]
sumSubseq (x : xs) = (summ (third x), (first x), (second x), third(x)) : sumSubseq xs

firstSum :: (Int, Int, Int,[Int]) -> Int
firstSum (x,_,_,[]) = x
firstSum (x,_,_,_) = x

insertSubseq :: (Int,Int, Int,[Int]) -> [(Int,Int, Int,[Int])] -> [(Int,Int, Int,[Int])]
insertSubseq x [] = [x]
insertSubseq x (y : ys)
          | firstSum x <= firstSum y = x : y : ys
          | otherwise = y : insertSubseq x ys

sortSums :: [(Int,Int, Int,[Int])]-> [(Int,Int, Int,[Int])]
sortSums [(x)] = [(x)]
sortSums (x : xs) = insertSubseq x (sortSums xs)

smallestksets :: Int -> [Int] -> [(Int,Int,Int,[Int])]
smallestksets k [x] = [(x, 1, (length [x]), [x])]
smallestksets k xs = take k (sortSums( sumSubseq (tailSubseq 1 (length xs) xs)))

firstSubseq :: [(Int, Int, Int,[Int])] -> (Int, Int, Int,[Int])
firstSubseq [x] = x
firstSubseq (x : xs) = x

printTuple :: [(Int, Int, Int, [Int])] -> String
printTuple [(summm,i,j,list)] = "  " ++ show summm ++ "   " ++ show i ++ "   " ++  show j ++ "   " ++ show list
printTuple ((summm,i,j,list) : xs) = "  " ++ show summm ++ "   " ++ show i ++
                                          "   " ++  show j ++ "   " ++ show list ++ "\n" ++ printTuple xs

printa :: Int -> [Int] -> String
printa k xs = "size   i   j   sublist\n" ++ printTuple(smallestksets k xs)

main :: IO()
main  = do
    let k = 15
    let xs = [-1,2,-3,4,-5]
    putStrLn(printa k xs)
--           -- main = do
--           --     let k = 15
--           --     let xs = []
--           --     if xs == []
--           --           then putStrLn(printa k xs)
--           --           else putStrLn("no")
--  main :: [Int] -> Int -> [Char]
-- main xs k =  putStrLn(printa k xs)
